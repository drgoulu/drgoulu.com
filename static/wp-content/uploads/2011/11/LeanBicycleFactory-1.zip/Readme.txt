Readme installation instructions for Lean Bicycle Factory.

1. To be able to run this game you need to have permission to run exe-files.
2. Download the self extracting file called LeanBicycleFactory.exe from http://www.ludosity.com/Lean
3. Double click on the downloaded LeanBicycleFactory.exe file.
4. It will ask you to install the game on a specific place on your hard drive. If the path doesnt fit your needs, pleace click on the Browse-button and choose your destination.
5. Click then on Install. When the installation is complete follow step 6.
6. Look up the destination folder where you installed the game and double click on Lean.exe.

If you are having any problems installing the game, please contact support@ludosity.com


Ludosity Interactive 
2009-11-06