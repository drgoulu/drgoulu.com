<?php

$file = "leanScore.txt";
if ($_SERVER['HTTP_USER_AGENT'] == "NinjaGameEngine/1.5/Lean") {
	$file = "score1.txt";
}

function filePutContents($name,$str,$mode="w") {
  $fh = fopen($name,$mode);
  fwrite($fh,$str);
  fclose($fh);
}

$scores = @array_map('trim',@file($file));

// If accessed from the game
if ($_SERVER['HTTP_USER_AGENT'] == "NinjaGameEngine/1.5/Lean" ||
	  $_SERVER['HTTP_USER_AGENT'] == "NinjaGameEngine/1.6/Lean"):

// Display as raw text
// allow adding new scores

$maxScores = 20;

if (isset($_GET['m'])) {
  $message = $_GET['m'];
  $message = explode(';',$message);

  if ($message[count($message)-1] == "END") {
    $score = $message[0];
    if (is_numeric($score)) { // Make sure it really is a number
      $data = $message[1];
			for ($i = 2; $i < count($message)-1; ++$i) {
				$data .= ";" . $message[$i];
			}
			
      $tScores = $scores;
      $tScores[] = $score.";".$data;
      rsort($tScores,SORT_NUMERIC);
      
      $scores = Array();
      for ($i=0; $i<min($maxScores,count($tScores)); $i++) {
         $scores[] = $tScores[$i];
      }

      filePutContents($file,$scores[0]);
      foreach ($scores as $key => $quote) {
			  if ($key!=0) {
          filePutContents($file,"\r\n".$quote,"a");
			  }
		  }
    }
  }
}

for ($i=0; $i<count($scores); $i++) {
  echo $scores[$i]."\n";
}

?><?php else: // Not accessed from the game, show regular HTML

?><html>
  <head>
    <title>Lean Scores</title>
	</head>
	<body>
		<table>
			<thead>
				<tr>
					<td>Name</td>
					<td>Score</td>
					<td>Time</td>
				</tr>
<?php

for ($i = 0; $i<count($scores); ++$i) {
	$data = explode(';',$scores[$i]);
	$score = $data[0];
	$name = $data[1];
	$time = $data[2];
	echo <<<EOF
				<tr>
					<td>$name</td>
					<td>$score</td>
					<td>$time</td>
				</tr>
EOF;
}

?>
		</table>
	</body>
</html>

<?php


endif;
?>
