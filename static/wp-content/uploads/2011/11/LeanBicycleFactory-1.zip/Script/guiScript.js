function exitYes(el) { game.exit(); return false; }
function exitNo(el) {}
function exitGame(el) {
	game.showModal(game.getString(305),"exitYes","exitNo","");
	return false;
}

function showPauseLibrary(el) {
	game.showLibrary(0);
	return false;
}

function pauseGame(el) {
	game.pause();
	return false;
}


/////////////////////////////////////////////////

function changeTime(el) {
	for (i=3; i>0; --i) {
		var id = "timeImg" + i;
		var obj = gui.getObjectById(id);
		obj.image = obj.getAttribute("inactiveImage");
//		obj.setAttribute("class","timeImageInactive");
//		obj.restore();
	}
	
	el.image = el.getAttribute("activeImage");
//	el.setAttribute("class","timeImageActive");
//	el.restore();
	
	game.timeFactor = el.getAttribute("value");
	return false;
}
