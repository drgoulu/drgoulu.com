/////////////////////////////////////////////////
// counterModule.js
// 
// Script for a counter module
// 
/////////////////////////////////////////////////


/////////////////////////////////////////////////

module.onInput = function(prod) { }


/////////////////////////////////////////////////

module.onCheckBuffer = function() { }


/////////////////////////////////////////////////

module.onOutput = function(prod) { }


/////////////////////////////////////////////////

module.onclick = function(area) {
	area.removeChildren();
	var text = gui.createObject("text","",100,area);
	text.text = this.name;
	
	var buttonPos = gui.createObject("button", "", 100, area);
	buttonPos.text = game.getString(600);
	buttonPos.setBounds(area.x + 5, area.y + 40, -1, -1);
	buttonPos.setAttribute("onclick", "changePos");
}


module.onAction = function(area) { return false; }