// testAssembly.js

module.onInput = function(prod) {
	var b = this.inBuffer;
	b.push(prod);
	return null;
}

module.onCheckBuffer = function() {
	var b = this.inBuffer;
	if (!b.empty) {
		this.processList.push(b.front);
		b.popFront();
	}
}

module.onOutput = function(prod) {
	this.outBuffer.push(prod);
	return null;
}
