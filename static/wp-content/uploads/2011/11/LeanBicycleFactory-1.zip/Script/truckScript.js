

function setBatch(value) {
	if (game.truckBatch != value) {
		game.truckBatch = value;
		game.registerChange();
	}
}

function showBatch(el) {
	var text = gui.createObject("text","",600);
	text.text = game.getString(610);
	text.setBounds(5,1,-1,-1);
	
	var text2 = gui.createObject("text","",600);
	text2.text = game.getString(2103);
	text2.setBounds(5,34,-1,-1);
	
	var batch = game.truckBatch;
	var box = showChangeBox("popupInfo",600,batch,1,4,setBatch,text,text2);
	box.setBounds(512-box.width*0.5,384-box.height*0.5,-1,-1);
}
function truckSellDummy() { game.registerChange(); }

function sellTruckOk() {
	game.sellCurrentTruck();
	game.closeModulePopup();
	game.addMoney(1000);
	hideModal();
	
	game.showModal(game.getString(2127),"truckSellDummy","","");
	
	return false;
}

function sellTruck(el) {
	var text = gui.createObject("text","",600);
	text.text = game.getString(2126);
	
	var desc = gui.createObject("text","",600);
	desc.text = game.getString(2125);
	desc.setBounds(0,text.y+text.height+5,-1,-1);
	
	var okBtn = gui.createObject("button","",601);
	okBtn.text = game.getString(2104);
	okBtn.setAttribute("onclick","sellTruckOk");
	okBtn.setBounds(10,desc.y+desc.height+10,-1,-1);
	
	var cancelBtn = gui.createObject("button","",601);
	cancelBtn.text = game.getString(2105);
	cancelBtn.setAttribute("onclick","hideModal");
	cancelBtn.setBounds(okBtn.x+okBtn.width+10,okBtn.y,-1,-1);
	
	var a = displayModal(550,"popupInfo",text,desc,okBtn,cancelBtn);
	a.setBounds(512 - a.width*0.5,384 - a.height*0.5,-1,-1);
}

function showTruckInfo(obj) {
	var text = gui.createObject("text","",400,obj);
	text.text = game.getString(1012);
	text.setBounds(obj.x + 10,obj.y + 10,-1,-1);
	
	var sellBtn = gui.createObject("button","",401,obj);
	sellBtn.text = game.getString(652);
	sellBtn.setBounds(obj.x +10,obj.y +50,-1,-1);
	sellBtn.setAttribute("onclick","sellTruck");
	
	var batchBtn = gui.createObject("button","",401,obj);
	batchBtn.text = game.getString(610);
	batchBtn.setBounds(obj.x +10,obj.y +90,-1,-1);
	batchBtn.setAttribute("onclick","showBatch");
}

