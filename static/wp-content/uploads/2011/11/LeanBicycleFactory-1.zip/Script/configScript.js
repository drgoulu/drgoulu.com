var infoArea;

function showInfo(el) {
	if (!infoArea) {
		infoArea = gui.createObject("group","infoBox",600,null);
	}

	var text = gui.createObject("text","",600,infoArea);
	text.text = game.getString(el.getAttribute("string"));
	infoArea.setBounds(el.x,el.y,-1,-1);
}

function hideInfo(el) {
	if (infoArea) {
		gui.removeObject(infoArea);
		infoArea = null;
	}
}
