/////////////////////////////////////////////////
// dummyModule.js
// A dummy script for modules
// just defines the event functions, so we won't
// get horrible errors...
//
// Well they wouldn't actually be all that horrible
// Also, this file can be used for reference for now
/////////////////////////////////////////////////


/////////////////////////////////////////////////
/* module.onInput
   Args: Product
   Return value: a product to send to storage,
	               or null/nothing
   The function is called every time the module
	 recieves a product, and decides what to do
	 with it. Can check if it should be processed
	 immediately, or sent to the input buffer,
	 or whatever
*/

module.onInput = function(prod) {
	var b = this.inBuffer;
	// If the inbuffer and processing list is empty, push directly to processing
	// Also make sure the outbuffer is not full
	if (b.empty && this.processList.empty && this.outBuffer.size < this.maxOutBuffer) {
		this.processList.push(prod);
		return;
	}
	// If the inbuffer is full, send to storage
	if (b.size >= this.maxInBuffer) return prod;
	
	// If no, send it to the inbuffer
	b.push(prod);
	return;
}


/////////////////////////////////////////////////
/* module.onCheckBuffer
   Args: none
	 Return value: none
	 Called when the module is ready to get more
	 stuff from the input buffer
*/

module.onCheckBuffer = function() {
	var b = this.inBuffer;
	
	// Send the first product in the inbuffer to processing, unless the outbuffer is full
	if (!b.empty && this.outBuffer.size < this.maxOutBuffer) {
		this.processList.push(b.front);
		b.popFront();
	}
}


/////////////////////////////////////////////////
/* module.onOutput
   Args: Product
	 Return value: a product to send to storage,
	               or null/nothing
	 Called every time a product is sent to the
	 module's output buffer. One use might be to
	 check if the product is special, and in that case
	 remove some item from the output buffer and
	 insert the special product instead
*/

module.onOutput = function(prod) {
	// Just send it to the outbuffer
	this.outBuffer.push(prod);
	return null;
}



/////////////////////////////////////////////////
/* module.onclick
   Args: An area area for gui objects
   Return value: none

   Called when a module is clicked in "change" mode
   Is supposed to create gui objects to change the
   module's data
*/

module.onclick = function(area) {
	area.removeChildren();
	var text = gui.createObject("text","",100,area);
	text.text = this.name;
	
	var buttonPos = gui.createObject("button", "", 100, area);
	buttonPos.text = "Change position";
	buttonPos.setBounds(area.x + 5, area.y + 35, -1, -1);
	buttonPos.setAttribute("onclick", "changePos");
	
	var buttonUpgrade = gui.createObject("button", "", 100, area);
	buttonUpgrade.text = "Upgrade machine";
	buttonUpgrade.setBounds(area.x + 5, area.y + 70, -1, -1);
	buttonUpgrade.setAttribute("onclick", "upgrade");
}

/////////////////////////////////////////////////
/* module.onAction
   Args: An area for gui objects
   Return value: false if nothing should be shown
	 
	 Called when a module is clicked during game play
	 Is supposed to create gui objects to change the
	 module's data
*/

module.onAction = function(area) { return false; }