/////////////////////////////////////////////////

function hideArea(el) {
	gui.removeObject(el);
	return false;
}

function displayArea() {
	// Displays a group that contains the objects passed as arguments
	var area = gui.createObject("group","dataBox",500,null);
	for (i=0; i<arguments.length; ++i) {
		// Add all the arguments as children
		var obj = arguments[i];
		area.addChild(obj);
	}
	// Remove the whole group when the mouse is no longer over it
	area.setAttribute("onmouseout","hideArea");
	return area;
}

/////////////////////////////////////////////////

var globalModalArea = 0;

function hideModal() {
	if (globalModalArea) {
		gui.removeObject(globalModalArea);
		globalModalArea = 0;
	}
	return false;
}

function displayModal(modalLayer,clsName) {
	// Utility function that creates a group that can act as a modal dialog
	// All objects passed as arguments will be contained within
	// Make sure they were created with layer > modalLayer
	// Call hideModal() to hide the whole thing
	
	// Only one modal at a time
	if (globalModalArea) { hideModal(); }
	globalModalArea = gui.createObject("group","",0);
	
	var modalImg = gui.createObject("img","",modalLayer,globalModalArea);
	modalImg.setBounds(0,0,1024,768);
	
	var area = gui.createObject("group",clsName,modalLayer+1,globalModalArea);
	for (i=2; i<arguments.length; ++i) {
		var obj = arguments[i];
		area.addChild(obj);
	}
	
	// Return the created display area
	return area;
}

/////////////////////////////////////////////////
// For displaying a box with +/- buttons

var changeData = null;

function hideChangeBox(el) {
	if (changeData) {
		gui.removeObject(changeData.modal);
		gui.removeObject(changeData.box);
		changeData = null;
	}
	return false;
}

function updateChangeBox(val) {
	if (changeData) {
		changeData.value += val;
		if (changeData.value < changeData.minVal) changeData.value = changeData.minVal;
		if (changeData.value > changeData.maxVal) changeData.value = changeData.maxVal;
		changeData.text.text = changeData.value;
		changeData.decBtn.visible = (changeData.value != changeData.minVal);
		changeData.incBtn.visible = (changeData.value != changeData.maxVal);
	}
}

function incChangeBox(el) { updateChangeBox(1); }
function decChangeBox(el) { updateChangeBox(-1); }
function callChangeOk(el) {
	changeData.okFunc(changeData.value);
	hideChangeBox();
	return false;
}

function showChangeBox(clsName,layer,startValue,min,max,okFunc) {
	// Creates a modal dialog with "increase" and "decrease" buttons
	// and "ok" and "cancel" buttons
	// clsName = class name for the box
	// layer = layer to display everything at
	// startValue = starting value
	// min = minimum value
	// max = maximum value
	// okFunc = a function that gets the final value when "ok" is clicked
	// Additional arguments are placed in the box above the buttons
	
	if (changeData) { hideChangeBox(); }
	
	changeData = new Object;
	
	var modal = gui.createObject("img","",layer-2);
	modal.setBounds(0,0,1024,768);
	changeData.modal = modal;
	
	var box = gui.createObject("group",clsName,layer-1);
	changeData.box = box;
	
	for (i=6; i<arguments.length; ++i) {
		box.addChild(arguments[i]);
	}
	
	box.setBounds(0,0,-1,-1);
	
	var decBtn = gui.createObject("button","",layer,box);
	decBtn.image = "Art/Gui/arrowLeft.png";
	decBtn.setBounds(box.x+10,box.height+5,20,20);
	decBtn.setAttribute("onclick","decChangeBox");
	changeData.decBtn = decBtn;
	if (startValue == min) decBtn.visible = false;
	
	var text = gui.createObject("text","",layer,box);
	text.text = startValue;
	text.setBounds(decBtn.x+decBtn.width+10,decBtn.y,-1,-1);
	changeData.text = text;
	
	var incBtn = gui.createObject("button","",layer,box);
	incBtn.image = "Art/Gui/arrowRight.png";
	incBtn.setBounds(text.x+text.width+10,decBtn.y,20,20);
	incBtn.setAttribute("onclick","incChangeBox");
	changeData.incBtn = incBtn;
	if (startValue == max) incBtn.visible = false;
	
	var okBtn = gui.createObject("button","",layer,box);
	okBtn.text = game.getString(2104);
	okBtn.setBounds(decBtn.x,decBtn.y+text.height+5,-1,-1);
	okBtn.setAttribute("onclick","callChangeOk");
	changeData.okFunc = okFunc;
	
	var cancelBtn = gui.createObject("button","",layer,box);
	cancelBtn.text = game.getString(2105);
	cancelBtn.setBounds(okBtn.x+okBtn.width+10,okBtn.y,-1,-1);
	cancelBtn.setAttribute("onclick","hideChangeBox");
	
	changeData.value = startValue;
	changeData.minVal = min;
	changeData.maxVal = max;
	
	box.setBounds(0,0,-1,-1);
	return box;
}

