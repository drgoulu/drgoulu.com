/////////////////////////////////////////////////
// storageModule.js
// 
// Script for a storage module
// Sends all input directly to the processList
/////////////////////////////////////////////////


/////////////////////////////////////////////////

module.onInput = function(prod) {
	var b = this.inBuffer;
	if (b.size >= this.maxInBuffer) return prod;
	b.push(prod);
	return;
}


/////////////////////////////////////////////////

module.onCheckBuffer = function() {
	if (!this.processList.empty) return;
	
	var b = this.inBuffer;
	// Send the first product in the inbuffer to processing, unless the outbuffer is full
	if (!b.empty && this.outBuffer.size < this.maxOutBuffer) {
		if (this.mode1 == 1) { // Smart mode
			// Check the inbuffer for an appropriate product
			for (i = b.size-1; i>=0; --i) {
				var product = b.get(i);
				if (product.type == this.mode2) {
					this.processProduct(product);
					b.erase(i);
					return;
				}
			}
			// Didn't find any good product, so get the next in line, and wait a while
			this.waitTime = this.baseWaitTime;
			this.mode2 = b.front.type;
			this.processProduct(b.front);
			b.popFront();
		} else { // FIFO mode (default)
			// Check if the product type is the same as the current setting, otherwise, wait a while
			if (b.front.type != this.mode2) {
				this.waitTime = this.baseWaitTime;
				this.mode2 = b.front.type;
			}
			
			// Always process the first in line
			this.processProduct(b.front);
			b.popFront();
		}
	}
}


/////////////////////////////////////////////////

module.onOutput = function(prod) {
	// Just send it to the outbuffer
	this.outBuffer.push(prod);
	return null;
}


/////////////////////////////////////////////////

module.onclick = function(area) {
	area.removeChildren();
	var text = gui.createObject("text","",100,area);
	text.text = this.name;
	
	var buttonPos = gui.createObject("button", "", 100, area);
	buttonPos.text = game.getString(600);
	buttonPos.setBounds(area.x + 5, area.y + 40, -1, -1);
	buttonPos.setAttribute("onclick", "changePos");
	
	var buttonSettings = gui.createObject("button", "", 100, area);
	buttonSettings.text = game.getString(609);
	buttonSettings.setBounds(area.x + 5, area.y + 80, -1, -1);
	buttonSettings.setAttribute("onclick", "castingConfigureTime");
	
	var buttonQA = gui.createObject("button", "", 100, area);
	buttonQA.text = game.getString(606);
	buttonQA.setBounds(area.x + 5, area.y +120, -1, -1);
	buttonQA.setAttribute("onclick", "qa");
}


module.onAction = function(area) { return false; }
