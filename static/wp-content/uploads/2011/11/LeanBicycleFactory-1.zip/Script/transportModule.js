/////////////////////////////////////////////////
// storageModule.js
// 
// Script for a storage module
// Sends all input directly to the processList
/////////////////////////////////////////////////


/////////////////////////////////////////////////

module.onInput = function(prod) {
	var b = this.inBuffer;
	if (b.size >= this.maxInBuffer) return prod;
	b.push(prod);
	return;
}


/////////////////////////////////////////////////

module.onCheckBuffer = function() {
	var b = this.inBuffer;
	
	// Send the first product in the inbuffer to processing, unless the outbuffer is full
	if (!b.empty && this.outBuffer.size < this.maxOutBuffer) {
		this.processList.push(b.front);
		b.popFront();
	}
}


/////////////////////////////////////////////////

module.onOutput = function(prod) {
	// Just send it to the outbuffer
	this.outBuffer.push(prod);
	return null;
}


/////////////////////////////////////////////////

module.onclick = function(area) {
	area.removeChildren();
	var text = gui.createObject("text","",100,area);
	text.text = this.name;
	
	var buttonBatch = gui.createObject("button", "", 100, area);
	buttonBatch.text = "Change batch size";
	buttonBatch.setBounds(area.x + 5, area.y +40, -1, -1);
	buttonBatch.setAttribute("onclick", "batch");
	
	var buttonSettings = gui.createObject("button", "", 100, area);
	buttonSettings.text = "Change behavior";
	buttonSettings.setBounds(area.x + 5, area.y +80, -1, -1);
	buttonSettings.setAttribute("onclick", "settings");
	
	var buttonUpgrade = gui.createObject("button", "", 100, area);
	buttonUpgrade.text = "Buy and Sell trucks";
	buttonUpgrade.setBounds(area.x + 5, area.y +120, -1, -1);
	buttonUpgrade.setAttribute("onclick", "settings");
}


module.onAction = function(area) { return false; }
