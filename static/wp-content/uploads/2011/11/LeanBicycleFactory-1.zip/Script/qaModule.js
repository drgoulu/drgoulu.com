/////////////////////////////////////////////////
// storageModule.js
// 
// Script for a storage module
// Sends all input directly to the processList
/////////////////////////////////////////////////


/////////////////////////////////////////////////

module.onInput = function(prod) {
	var b = this.inBuffer;
	if (b.size >= this.maxInBuffer) return prod;
	b.push(prod);
	return;
}


/////////////////////////////////////////////////

module.onCheckBuffer = function() {
	var b = this.inBuffer;
	
	// Send the first product in the inbuffer to processing, unless the outbuffer is full
	if (!b.empty && this.outBuffer.size < this.maxOutBuffer) {
		this.processProduct(b.front);
		b.popFront();
	}
}


/////////////////////////////////////////////////

module.onOutput = function(prod) {
	if (prod.damage > prod.maxDamage) {
		// Product is damaged - do something!
		game.signalProduct(this,prod);
		return;
	}

	this.outBuffer.push(prod);
	return null;
}


/////////////////////////////////////////////////

module.onclick = function(area) {
	area.removeChildren();
	var text = gui.createObject("text","",100,area);
	text.text = this.name;
	
	var buttonPos = gui.createObject("button", "", 100, area);
	buttonPos.text = game.getString(600);
	buttonPos.setBounds(area.x + 5, area.y + 40, -1, -1);
	buttonPos.setAttribute("onclick", "changePos");
	
	var buttonSettings = gui.createObject("button", "", 100, area);
	buttonSettings.text = game.getString(611);
	buttonSettings.setBounds(area.x + 5, area.y + 80, -1, -1);
	buttonSettings.setAttribute("onclick", "sellQa");
}


module.onAction = function(area) { return false; }
