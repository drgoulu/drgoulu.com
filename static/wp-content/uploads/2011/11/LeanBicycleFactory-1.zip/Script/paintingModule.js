
/////////////////////////////////////////////////

module.onInput = function(prod) {
	this.inBuffer.push(prod);
	return;
}


/////////////////////////////////////////////////

module.onCheckBuffer = function() {
	var b = this.inBuffer;
	var out = this.outBuffer;
	var p = this.processList;
	if (!p.empty) return;
	
	if (!b.empty && out.size < this.maxOutBuffer) {
		var threshold = this.bufferThreshold;
		
		var getType = -1;
		var typesList = [];
		for (i = b.size-1; i>=0; --i) {
			var t = b.get(i).type;
			if (!typesList[t]) typesList[t] = 0;
			if (++typesList[t] >= threshold) {
				getType = t; break;
			}
		}
		if (getType < 0) return;

		var processThreshold = 4;
		for (i = b.size-1; i>=0 && p.size < processThreshold; --i) {
			var product = b.get(i);
			if (product.type == getType) {
				this.processProduct(product);
				b.erase(i);
			}
		}
	}
}


/////////////////////////////////////////////////

module.onOutput = function(prod) {
	// Just send it to the outbuffer
	this.outBuffer.push(prod);
	return null;
}


/////////////////////////////////////////////////

module.onclick = function(area) {
	area.removeChildren();
	var text = gui.createObject("text","",100,area);
	text.text = this.name;
	
	var buttonPos = gui.createObject("button", "", 100, area);
	buttonPos.text = game.getString(600);
	buttonPos.setBounds(area.x + 5, area.y + 40, -1, -1);
	buttonPos.setAttribute("onclick", "changePos");
	
	var buttonUpgrade = gui.createObject("button", "", 100, area);
	buttonUpgrade.text = game.getString(608);
	buttonUpgrade.setBounds(area.x + 5, area.y + 80, -1, -1);
	buttonUpgrade.setAttribute("onclick", "upgradePainting"); //upgradePainting
	
	this.mode1 = 4;
	var buttonSettings = gui.createObject("button", "", 100, area);
	buttonSettings.text = game.getString(610);
	buttonSettings.setBounds(area.x + 5, area.y + 120, -1, -1);
	buttonSettings.setAttribute("onclick", "pbsBatchSettings");
	
	var buttonQA = gui.createObject("button", "", 100, area);
	buttonQA.text = game.getString(606);
	buttonQA.setBounds(area.x + 5, area.y +160, -1, -1);
	buttonQA.setAttribute("onclick", "qa");
}

module.onAction = function(area) { return false; }
