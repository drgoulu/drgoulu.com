
/////////////////////////////////////////////////


function changePos(obj)
{
	game.moveSelectedModule();
}

function upgrade(obj)
{
	game.upgradeMachine();
}

function settings(obj)
{
	
}

/////////////////////////////////////////////////
// Cleaning settings

var cleaningCheckValue = 0;

function setCleaningSettings(el) {
	cleaningCheckValue = el.selected;
	return true;
}

function cleaningSettingsOk(el) {
	var v = (game.cleanModules > 0);
	if (v != cleaningCheckValue) {
		if (v) game.cleanModule = 1.0;
		else game.cleanModule = 0;
		game.registerChange();
	}
	hideModal();
	return false;
}

function cleaningButtonPressed(el) {
	var text = gui.createObject("text", "", 600, null);
	text.text = game.getString(602);
	
	var desc = gui.createObject("text", "", 600);
	desc.text = game.getString(2123);
	desc.setBounds(0,text.y+text.height+5,-1,-1);
	
	var checkbox = gui.createObject("checkbox", "", 600, null);
	checkbox.setBounds(10, desc.y+desc.height+5, -1, -1);
	checkbox.setAttribute("onclick", "setCleaningSettings");
	checkbox.selected = (game.cleanModules > 0);
	cleaningCheckValue = checkbox.selected;

	var okBtn = gui.createObject("button", "", 601);
	okBtn.text = game.getString(2104);
	okBtn.setAttribute("onclick", "cleaningSettingsOk");
	okBtn.setBounds(10,checkbox.y + checkbox.height + 10,-1,-1);
	
	var a = displayModal(550,"popupInfo",text, desc, checkbox, okBtn);
	a.setBounds(512-a.width*0.5,384-a.height*0.5,-1,-1);
}


/////////////////////////////////////////////////
// Production schedule

var prodSchemeStart = 0;

function changeSchedule(el) {
	game.currentScheme = el.selectedIndex;
}

function clickScheduleOk(el) {
	if (game.currentScheme != prodSchemeStart) {
		game.registerChange();
	}
	hideModal();
	return false;
}

function clickScheduleHelp(el) {
	game.showLibrary(3);
	return false;
}

function showSchedule(el) {
	var text = gui.createObject("text","",600,null);
	text.text = game.getString(601);
	text.setBounds(0,0,-1,-1);
	
	var desctext = gui.createObject("text","",600,null);
	desctext.text = game.getString(2120);
	desctext.setBounds(0,30,-1,-1);
	
	// Create radio group with production schedule options
	var radioGroup = gui.createObject("radiogroup","",600,null);
	var y = 170;
	for (i = 0; i<2; ++i) {
		var radio = gui.createObject("radio","",600,null);
		radio.setBounds(0,y+10,-1,-1);
		radioGroup.addChild(radio);
		
		// Create a text for the option
		var radioText = gui.createObject("text","",600,null);
		radioText.text = game.getString(2121 + i); 
		radioText.setBounds(radio.width + 8,y,-1,-1);
		radioGroup.addChild(radioText);
		y += radioText.height;
	}
	
	radioGroup.selectedIndex = game.currentScheme;
	radioGroup.setBounds(0,text.height+5,-1,-1);
	radioGroup.setAttribute("onchange","changeSchedule");
	prodSchemeStart = game.currentScheme;
	
	var helpBtn = gui.createObject("button","",600,null);
	helpBtn.text = game.getString(2050);
	helpBtn.setBounds(50,radioGroup.y+radioGroup.height+5,-1,-1);
	helpBtn.setAttribute("onclick","clickScheduleHelp");
	
	var okBtn = gui.createObject("button","",600);
	okBtn.text = game.getString(2104);
	okBtn.setBounds(0,radioGroup.y + radioGroup.height + 5,-1,-1);
	okBtn.setAttribute("onclick","clickScheduleOk");
	
	var a = displayModal(550,"popupInfo",text,desctext,radioGroup,helpBtn,okBtn);
	a.setBounds(512-a.width*0.5,384-a.height*0.5,-1,-1);
/*	var a = displayArea(text,radioGroup,helpBtn);
	a.setBounds(el.x,el.y-10,-1,-1);
	if (a.y + a.height > 768) {
		a.setBounds(a.x,768-a.height,-1,-1);
	}*/
}


/////////////////////////////////////////////////
// QA settings

function batch(obj)
{
	game.changeBatch();
}

function qaYes() {
	game.selectedModule.qa = 1.0;
	game.selectedModule.waitTime = game.selectedModule.waitTime * 1.3;
	game.registerChange();
}
function qaNo() {
	game.selectedModule.qa = 0.0;
}
function qa(obj)
{
	game.showModal(game.getString(2113),"qaYes","qaNo","");
//	game.selectedModule.qa = 0;
}

function qaSellDummy() {
	game.registerChange();
}
function qaSellYes() {
	game.removeModule(game.selectedModule);
	game.addMoney(250);
	game.closeModulePopup();
	hideModal();
	
	game.showModal(game.getString(2127),"qaSellDummy","","");
	return false;
}
function qaSellNo() { }
function sellQa(obj) {
	var text = gui.createObject("text","",600,null);
	text.text = game.getString(2109);
	
	var desc = gui.createObject("text","",600,null);
	desc.text = game.getString(2110);
	desc.setBounds(0,text.height+10,-1,-1);
	
	var okBtn = gui.createObject("button","",600,null);
	okBtn.text = game.getString(2104);
	okBtn.setBounds(10,desc.y+desc.height+10,-1,-1);
	okBtn.setAttribute("onclick","qaSellYes");
	
	var cancelBtn = gui.createObject("button","",600,null);
	cancelBtn.text = game.getString(2105);
	cancelBtn.setBounds(okBtn.x + okBtn.width + 10,okBtn.y,-1,-1);
	cancelBtn.setAttribute("onclick","hideModal");
	
	var area = displayModal(500,"popupInfo",text,desc,okBtn,cancelBtn);
	area.setBounds(200,200,-1,-1);
	
//	game.showModal("ARE YOU SURE?!?!?","qaSellYes","qaSellNo");
}

function notImplemented(obj)
{
	print("Sorry, but that feature is not yet implemented.");
}

/////////////////////////////////////////////////
// Painting settings

function upgradePaintingOk(obj) {
	game.addMoney(-game.selectedModule.cost);
	game.selectedModule.changeType("Painting2");
	game.selectedModule.bufferThreshold = 2;
	game.registerChange();
	game.closeModulePopup();
	hideModal();	
	return false;
}

function upgradePainting(obj) {
	var text = gui.createObject("text","",600);
	text.text = game.getString(2111);
	
	var desc = gui.createObject("text","",600);
	desc.text = game.getString(2112);
	desc.setBounds(0,text.y+text.height+5,-1,-1);
	
	var okBtn = gui.createObject("button","",601);
	okBtn.text = game.getString(2104);
	okBtn.setBounds(10,desc.y+desc.height+10,-1,-1);
	okBtn.setAttribute("onclick","upgradePaintingOk");
	
	var cancelBtn = gui.createObject("button","",601);
	cancelBtn.text = game.getString(2105);
	cancelBtn.setBounds(okBtn.x+okBtn.width+10,okBtn.y,-1,-1);
	cancelBtn.setAttribute("onclick","hideModal");
	
	var area = displayModal(550,"popupInfo",text,desc,okBtn,cancelBtn);
	area.setBounds(200,200,-1,-1);
}

function pbsBatchSettings(obj)
{
//    game.closeModulePopup();
    
    var clsName = "";
    var layer = 15000;
    
    var text = gui.createObject("text", clsName, layer);
    text.text = game.getString(2106);
    text.setBounds(5, 5, 100, 20);

    var desc = gui.createObject("text", "small", layer);
    desc.text = game.getString(2107);
    desc.setBounds(5, 40, 100, 65);
    
		var value = game.selectedModule.bufferThreshold;
		var area = showChangeBox("paintingBatch",layer,value,1,game.selectedModule.mode1,pbsOk,text,desc);
		area.setBounds(10,30,-1,-1);
}

function pbsOk(value)
{
    if (game.selectedModule.bufferThreshold != value)
    {
				game.selectedModule.bufferThreshold = value;
        game.registerChange();
    }
}



/////////////////////////////////////////////////
// Planning settings

var personnelText = 0;

function updatePersonnel() {
	personnelText.text = game.getString(2114) + " " + game.getWorkers(0);
}

function planningOkDummy(el) { }
function planningStatYes(el) {
	game.addWorkers(0,-1);
	game.addWorkers(1,1);
	game.registerChange();
	hideModal();
}
function planningMarketYes(el) {
	game.addWorkers(0,-1);
	game.addWorkers(2,1);
	game.registerChange();
	hideModal();
}
function planningStatCheck(el) {
	if (game.getWorkers(0) <= 0) {
		game.showModal(game.getString(2115),"planningOkDummy","");
		return false;
	}
	game.showModal(game.getString(2116),"planningStatYes","planningOkDummy");
}
function planningMarketCheck(el) {
	if (game.getWorkers(0) <= 0) {
		game.showModal(game.getString(2115),"planningOkDummy","");
		return false;
	}
	game.showModal(game.getString(2116),"planningMarketYes","planningOkDummy");
}

function showPersonnelDialog(el) {
	var text = gui.createObject("text","",600,null);
	text.text = game.getString(2117);
	
	var descText = gui.createObject("text","",600,null);
	descText.text = game.getString(2124);
	descText.setBounds(0,text.height+5,-1,-1);
	
	personnelText = gui.createObject("text","",600,null);
	personnelText.text = game.getString(2114) + " " + game.getWorkers(0);
	personnelText.setBounds(0,descText.y+descText.height+5,-1,-1);
	
	var statBtn = gui.createObject("button","",600,null);
	statBtn.text = game.getString(2118);
	statBtn.setBounds(10,personnelText.y + personnelText.height + 5,-1,-1);
	statBtn.setAttribute("onclick","planningStatCheck");
	
	var marketBtn = gui.createObject("button","",600,null);
	marketBtn.text = game.getString(2119);
	marketBtn.setBounds(10,statBtn.y+statBtn.height + 5,-1,-1);
	marketBtn.setAttribute("onclick","planningMarketCheck");
	
	var okButton = gui.createObject("button","",600,null);
	okButton.text = game.getString(2104);
	okButton.setAttribute("onclick","hideModal");
	okButton.setBounds(10,marketBtn.y+marketBtn.height + 15,-1,-1);
	
	var a = displayModal(500,"popupInfo",text,descText,personnelText,statBtn,marketBtn,okButton);
	a.setBounds(200,200,-1,-1);
}


/////////////////////////////////////////////////
// Casting settings

function castingOkDummy() { }

function castingFifoYes() {
	if (game.selectedModule.mode1 == 0) return;
	game.selectedModule.mode1 = 0;
	game.registerChange();
	hideModal();
}
function castingFifoCheck(el) {
	game.showModal(game.getString(2132),"castingFifoYes","castingOkDummy");
}

function castingSmartYes() {
	if (game.selectedModule.mode1 == 1) return;
	game.selectedModule.mode1 = 1;
	game.registerChange();
	hideModal();
}
function castingSmartCheck(el) {
	game.showModal(game.getString(2133),"castingSmartYes","castingOkDummy");
}

function castingConfigureTime(obj) {
	var text = gui.createObject("text","",600);
	text.text = game.getString(2128);
	
	var descText = gui.createObject("text","",600);
	descText.text = game.getString(2129) + " " + game.getString(2130+game.selectedModule.mode1);
	descText.setBounds(0,text.y+text.height + 5,-1,-1);
	
	var fifoBtn = gui.createObject("button","",600);
	fifoBtn.text = game.getString(2130);
	fifoBtn.setBounds(10,descText.y+descText.height+10,-1,-1);
	fifoBtn.setAttribute("onclick","castingFifoCheck");
	
	var smartBtn = gui.createObject("button","",600);
	smartBtn.text = game.getString(2131);
	smartBtn.setBounds(10,fifoBtn.y+fifoBtn.height+5,-1,-1);
	smartBtn.setAttribute("onclick","castingSmartCheck");
	
	var okBtn = gui.createObject("button","",600);
	okBtn.text = game.getString(2104);
	okBtn.setAttribute("onclick","hideModal");
	okBtn.setBounds(10,smartBtn.y+smartBtn.height+15,-1,-1);
	
	var a = displayModal(500,"popupInfo",text,descText,fifoBtn,smartBtn,okBtn);
	a.setBounds(512-a.width*0.5,384-a.height*0.5,-1,-1);
}
