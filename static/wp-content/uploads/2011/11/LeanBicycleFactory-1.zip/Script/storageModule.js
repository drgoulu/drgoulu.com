/////////////////////////////////////////////////
// storageModule.js
// 
// Script for a storage module
// Sends all input directly to the processList
/////////////////////////////////////////////////


/////////////////////////////////////////////////

module.onInput = function(prod) {
	this.processProduct(prod);
	return;
}


/////////////////////////////////////////////////

module.onCheckBuffer = function() {
	var b = this.inBuffer;
	
	// Send the first product in the inbuffer to processing, unless the outbuffer is full
	if (!b.empty && this.outBuffer.size < this.maxOutBuffer) {
		this.processProduct(b.front);
		b.popFront();
	}
}


/////////////////////////////////////////////////

module.onOutput = function(prod) {
	// Just send it to the outbuffer
	this.outBuffer.push(prod);
	return null;
}


/////////////////////////////////////////////////

module.onclick = function(area) {
	area.removeChildren();
	var text = gui.createObject("text","",100,area);
	text.text = this.name;
	
	var buttonPos = gui.createObject("button", "", 100, area);
	buttonPos.text = game.getString(600);
	buttonPos.setBounds(area.x + 5, area.y + 40, -1, -1);
	buttonPos.setAttribute("onclick", "changePos");
	
	//Storage Settings
	var buttonSettings = gui.createObject("button", "", 100, area);
	buttonSettings.text = game.getString(607);
	buttonSettings.setBounds(area.x + 5, area.y + 80, -1, -1);
	buttonSettings.setAttribute("onclick", "notImplemented");
}


module.onAction = function(area) { return false; }