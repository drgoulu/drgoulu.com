/////////////////////////////////////////////////
// storageModule.js
// 
// Script for a storage module
// Sends all input directly to the processList
/////////////////////////////////////////////////


/////////////////////////////////////////////////

module.onInput = function(prod) {
	var b = this.inBuffer;
	if (b.size >= this.maxInBuffer) return prod;
	b.push(prod);
	return;
}


/////////////////////////////////////////////////

module.onCheckBuffer = function() {
	var b = this.inBuffer;
	
	// Send the first product in the inbuffer to processing, unless the outbuffer is full
	if (!b.empty && this.outBuffer.size < this.maxOutBuffer) {
		this.processProduct(b.front);
		b.popFront();
	}
}


/////////////////////////////////////////////////

module.onOutput = function(prod) {
	// Just send it to the outbuffer
	this.outBuffer.push(prod);
	return null;
}


/////////////////////////////////////////////////

module.onclick = function(area) {
    var text = gui.createObject("text", "", 100, area);
    text.text = this.name;

    // Create move button
    var buttonPos = gui.createObject("button", "", 100, area);
    buttonPos.text = game.getString(600); // Move string
    buttonPos.setBounds(area.x + 5, area.y + 40, -1, -1);
    buttonPos.setAttribute("onclick", "changePos");

    // Create production schedule button
    var buttonSettings = gui.createObject("button", "", 100, area);
    buttonSettings.text = game.getString(601);
    buttonSettings.setBounds(area.x + 5, area.y + 80, -1, -1);
    buttonSettings.setAttribute("onclick", "showSchedule");

    // Create cleaning button
    var buttonCleaning = gui.createObject("button", "", 100, area);
    buttonCleaning.text = game.getString(602);
    buttonCleaning.setBounds(area.x + 5, area.y + 120, -1, -1);
    buttonCleaning.setAttribute("onclick", "cleaningButtonPressed");

    // Create personnel button
    var buttonPersonnel = gui.createObject("button", "", 100, area);
    buttonPersonnel.text = game.getString(603);
    buttonPersonnel.setBounds(area.x + 5, area.y + 160, -1, -1);
    buttonPersonnel.setAttribute("onclick", "showPersonnelDialog");
}

module.onAction = function(area) {
	var text = gui.createObject("text","",100,area);
	text.text = "HELLO!";
}
